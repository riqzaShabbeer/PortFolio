import React from 'react'
import { briefCase } from "./atom/svgs"
import { Card } from "./atom/Card"


export const DeveloperStory = () => {
  return (
    <div className="container px-4 mx-auto">
      <div className="lg:space-x-5 lg:flex lg:flex-row item-center lg:-mx-4 flex flex-col-reverse text-center lg:text-left">
        <div className="lg:px-4 lg:mt-12 ">
          <h1 className="text-2xl font-bold text-gray-900 lg:text-5xl dark:text-white">
            Developer Story
          </h1>
          <div className="mt-6 text-gray-800 dark:text-white">
            <p className='bg-gray-100 rounded-full w-14 h-14 flex items-center justify-center m-auto w-15 dark:text-white dark:bg-gray-700'>  2021 </p>
            <div className='bg-gray-400 w-0.5 h-14 m-auto w-15 ' />
            <div className='flex'>
              {briefCase}
              <Card />
            </div>
            <div className='bg-gray-400 w-0.5 h-14 m-auto w-15' />
            {briefCase}
            <div className='bg-gray-400 w-0.5 h-14 m-auto w-15' />
            {briefCase}

            {/* <p className="mb-4">
              Lorem Ipsum is simply dummy text of the printing and typesetting industry.
              Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
              when an unknown printer took a galley of type and scrambled it to make a
              type specimen book.
            </p> */}
          </div>
        </div>
      </div>
    </div>
  )
}

