import React from 'react'

export const Card = () => {
  return (
    <div>
      <div className='w-20 h-20 dark:bg-gray dark:text-white dark:bg-gray-700 bg-gray-200'>

      </div>

    </div>
  )
}

